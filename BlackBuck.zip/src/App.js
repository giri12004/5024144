import React, { Component } from 'react';
import { Route, Routes, Link } from 'react-router-dom';
import BookABike from './Components/BookABike';
import Info from './Components/Info';

const styles = {
  h1: {
    color: '#fff8dc',
    fontWeight: 'bold',
    backgroundColor: '#8fbc8f',
    fontStyle: 'oblique',
    textAlign: 'center',
  },
  h2: {
    color: '#228b22',
    fontWeight: 'bold',
    fontStyle: 'oblique',
    textAlign: 'center',
  },
  nav: {
    display: 'flex',
    justifyContent: 'center',
    margin: '20px 0',
  },
  link: {
    margin: '0 15px',
    textDecoration: 'none',
    color: '#000',
    fontWeight: 'bold',
  },
};

class App extends Component {
  render() {
    return (
      <div>
        <h1 style={styles.h1}>BlackBuck Dealers</h1>
        <h2 style={styles.h2}>Online Electric Bike Booking</h2>
        <nav style={styles.nav}>
          <Link to="/info" style={styles.link}>
            Info
          </Link>
          <Link to="/bookabike" style={styles.link}>
            BookABike
          </Link>
        </nav>
        <Routes>
          <Route path="/info" element={<Info />} />
          <Route path="/bookabike" element={<BookABike />} />
        </Routes>
      </div>
    );
  }
}

export default App;