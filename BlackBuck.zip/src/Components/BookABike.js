import React, { Component } from 'react';
import './form.css';

class BookABike extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      email: '',
      mobile: '',
      licenseId: '',
      licenseExpiryDate: '',
      brand: '',
      color: '',
      message: '',
    };
  }

  handleChange = (e) => {
    this.setState({ [e.target.id]: e.target.value });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const { name, email, mobile, licenseId, licenseExpiryDate, brand, color } = this.state;

    if (!name || !email || !mobile || !licenseId || !licenseExpiryDate || !brand || !color) {
      this.setState({ message: 'Please fill all the required fields' });
      return;
    }

    if (licenseId.length < 9 || licenseId.length > 13) {
      this.setState({ message: 'Check your License Number and register again' });
      return;
    }

    const currentDate = new Date();
    const expiryDate = new Date(licenseExpiryDate);

    if (expiryDate <= currentDate) {
      this.setState({ message: `Hai ${name} !!!. Check your License Validity and register again` });
      return;
    }

    const deliveryDate = new Date(currentDate);
    deliveryDate.setDate(deliveryDate.getDate() + 20);

    this.setState({
      message: `Hai ${name}. Your Registration for ${brand} is successful. Tentative Delivery Date will be on ${deliveryDate.toLocaleDateString(
        'en-GB'
      )}`,
    });
  };

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <h1>Bon Voyage!!</h1>
        <table>
          <tbody>
            <tr>
              <td>Name:</td>
              <td>
                <input type="text" id="name" onChange={this.handleChange} />
              </td>
            </tr>
            <tr>
              <td>Email Id:</td>
              <td>
                <input type="email" id="email" onChange={this.handleChange} />
              </td>
            </tr>
            <tr>
              <td>Mobile Number:</td>
              <td>
                <input type="tel" id="mobile" onChange={this.handleChange} />
              </td>
            </tr>
            <tr>
              <td>License Id:</td>
              <td>
                <input type="text" id="licenseId" onChange={this.handleChange} />
              </td>
            </tr>
            <tr>
              <td>License Expiry Date:</td>
              <td>
                <input type="date" id="licenseExpiryDate" onChange={this.handleChange} />
              </td>
            </tr>
            <tr>
              <td>Brand Selection:</td>
              <td>
                <select id="brand" onChange={this.handleChange}>
                  <option value="">Select Brand</option>
                  <option value="Benling">Benling Aura</option>
                  <option value="ipraise">Okiawa i-Praise</option>
                  <option value="Hero">Hero Electric Nyx</option>
                  <option value="Revolt">Revolt RV</option>
                </select>
              </td>
            </tr>
            <tr>
              <td>Choose Colour:</td>
              <td>
                <select id="color" onChange={this.handleChange}>
                  <option value="">Select Colour</option>
                  <option value="Red">Rebel Red</option>
                  <option value="Grey">Mist Grey</option>
                  <option value="Black">Cosmic Black</option>
                </select>
              </td>
            </tr>
          </tbody>
        </table>
        <div id="st">
          <button type="submit" id="submit" name="Submit">
            Submit
          </button>
        </div>
        <div id="display">{this.state.message}</div>
      </form>
    );
  }
}

export default BookABike;