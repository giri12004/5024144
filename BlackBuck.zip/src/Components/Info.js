import React, { Component } from 'react';

const styles = {
  h1: {
    color: '#b22222',
    textAlign: 'center',
  },
  h2: {
    color: '#b22222',
  },
  p: {
    fontSize: 'large',
    color: '#dc143c',
  },
  div: {
    backgroundColor: '#ffe4c4',
    borderStyle: 'dotted',
    color: '#4c684c',
    padding: '20px',
    margin: '20px auto',
    width: '60%',
  },
};

const data = [
  { bikename: 'Benling Aura', cost: '$500', batteryChargeTime: '3.5 hours', speed: '15 mph' },
  { bikename: 'Okiawa i-Praise', cost: '$1000', batteryChargeTime: '5 hours', speed: '20 mph' },
  { bikename: 'Hero Electric Nyx', cost: '$1500', batteryChargeTime: '7 hours', speed: '25 mph' },
  { bikename: 'Revolt RV', cost: '$1800', batteryChargeTime: '8 hours', speed: '30 mph' },
];

class Info extends Component {
  render() {
    return (
      <div style={styles.div}>
        <h1 style={styles.h1}>It's Great to see you in future!!!</h1>
        <h2 style={styles.h2}>Please find the details below:</h2>
        {data.map((bike) => (
          <dl key={bike.bikename}>
            <dt>{bike.bikename}</dt>
            <dd>Cost: {bike.cost}</dd>
            <dd>Battery Charge Time: {bike.batteryChargeTime}</dd>
            <dd>Speed: {bike.speed}</dd>
          </dl>
        ))}
        <p style={styles.p}>
          Electric bikes are the future of transportation. They are eco-friendly and cost-effective.
        </p>
        <p style={styles.p}>
          Choose your favorite bike and book it now to enjoy a smooth and sustainable ride!
        </p>
      </div>
    );
  }
}

export default Info;