package com.bookstore.BookStoreAPI.mapper;


import com.bookstore.BookStoreAPI.dto.BookDTO;
import com.bookstore.BookStoreAPI.model.Book;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BookMapper {
    BookMapper INSTANCE = Mappers.getMapper(BookMapper.class);

    BookDTO toBookDTO(Book book);
    Book toBook(BookDTO bookDTO);
}