package com.bookstore.BookStoreAPI.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.Data;

@Data
public class BookDTO {
    private Long id;

    @JsonProperty("book_title")
    private String title;

    private String author;

    
    @JsonDeserialize(using = CustomPriceDeserializer.class)
    @JsonSerialize(using = CustomPriceSerializer.class)
    private double price;

    private String isbn;
}