package com.bookstore.BookStoreAPI.model;

import lombok.Data;
@Entity
@Table(name = "customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(min = 1, max = 50)
    private String name;

    @NotNull
    @Email
    private String email;

    @NotNull
    @Size(min = 10, max = 100)
    private String address;

    @Version
    private int version;

    // Getters and Setters
}
