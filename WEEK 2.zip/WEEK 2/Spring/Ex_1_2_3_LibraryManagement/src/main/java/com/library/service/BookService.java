package com.library.service;

import com.library.repositary.BookRepository;

public class BookService {
    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void addBook(String book) {
        bookRepository.save(book);
    }

    public void removeBook(String book) {
        bookRepository.delete(book);
    }

    public void listBooks() {
        bookRepository.findAll();
    }
}
