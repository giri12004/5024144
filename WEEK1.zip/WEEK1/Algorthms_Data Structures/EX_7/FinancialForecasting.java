public class FinancialForecasting {
    public double calculateFutureValue(double principal, double growthRate, int years) {
        // Base case: if years is 0, return the principal amount
        if (years == 0) {
            return principal;
        }
        // Recursive case: calculate future value for one year less and apply growth
        return calculateFutureValue(principal * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        FinancialForecasting forecasting = new FinancialForecasting();
        
        double principal = 1000;
        double growthRate = 0.05;
        int years = 10;
        
        double futureValue = forecasting.calculateFutureValue(principal, growthRate, years);
        System.out.println("Future Value: " + futureValue);
    }
}
