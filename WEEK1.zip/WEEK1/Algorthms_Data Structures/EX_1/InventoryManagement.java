import java.util.ArrayList;

public class InventoryManagement {
    private ArrayList<Inventory> inventory;

    public InventoryManagement() {
        inventory = new ArrayList<>();
    }

    // Method to add a product
    public void addProduct(Inventory product) {
        inventory.add(product);
        System.out.println("Inventory Added!");
    }

    // Method to update a product
    public void updateProduct(Inventory product) {
        for (int i = 0; i < inventory.size(); i++) {
            if (inventory.get(i).getProductId().equals(product.getProductId())) {
                inventory.set(i, product);
                return;
            }
        }
        System.out.println("Inventory Updated!");
    }

    // Method to delete a product
    public void deleteProduct(String productId) {
        for (int i = 0; i < inventory.size(); i++) {
            if (inventory.get(i).getProductId().equals(productId)) {
                inventory.remove(i);
                return;
            }
        }
        System.out.println("Inventory not found!");
    }

    // Method to display all products
    public void displayProducts() {
        for (Inventory product : inventory) {
            System.out.println(product);
        }
    }
}
