import java.util.Arrays;

public class ProductManagement {
    private Product[] products;
    private int size;

    public ProductManagement(int capacity){
        products = new Product[capacity];
        size = 0;
    }

    public void addProduct(Product newProduct) {
        if (size == products.length) {
            products = Arrays.copyOf(products, size + 1);
        }

        int i;
        for (i = size - 1; (i >= 0 && products[i].getProductId() > newProduct.getProductId()); i--) {
            products[i + 1] = products[i];
        }
        products[i + 1] = newProduct;
        size++;
    }

    public Product[] getProducts() {
        return Arrays.copyOf(products, size);
    }

    
    public static Product linearSearch(Product[] products, int targetId) {
        for (Product product : products) {
            if (product.getProductId() == targetId) {
                return product;
            }
        }
        return null;
    }

    public static Product binarySearch(Product[] products, int targetId) {
        int left = 0;
        int right = products.length - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (products[mid].getProductId() == targetId) {
                return products[mid];
            }
            if (products[mid].getProductId() < targetId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
}
