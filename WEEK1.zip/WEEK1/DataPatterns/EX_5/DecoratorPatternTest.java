

public class DecoratorPatternTest {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier emailAndSMSNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier emailSMSAndSlackNotifier = new SlackNotifierDecorator(emailAndSMSNotifier);

        System.out.println("Sending email only:");
        emailNotifier.send("Hello via Email!");

        System.out.println("\nSending email and SMS:");
        emailAndSMSNotifier.send("Hello via Email and SMS!");

        System.out.println("\nSending email, SMS, and Slack:");
        emailSMSAndSlackNotifier.send("Hello via Email, SMS, and Slack!");
    }
}

