// BuilderPatternTest.java


public class BuilderPatternTest {
    public static void main(String[] args) {
        // Create different configurations of Computer using the Builder
        Computer gamingComputer = new Computer.Builder()
                .setCPU("Intel Core i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setPowerSupply("750W")
                .setMotherboard("ASUS ROG")
                .setCoolingSystem("Liquid Cooling")
                .build();

        Computer officeComputer = new Computer.Builder()
                .setCPU("Intel Core i5")
                .setRAM("16GB")
                .setStorage("512GB SSD")
                .build();

        Computer budgetComputer = new Computer.Builder()
                .setCPU("AMD Ryzen 3")
                .setRAM("8GB")
                .setStorage("256GB SSD")
                .build();

        // Display the configurations
        System.out.println(gamingComputer);
        System.out.println(officeComputer);
        System.out.println(budgetComputer);
    }
}

