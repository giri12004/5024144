

public class AdapterPatternTest {
    public static void main(String[] args) {
        PaymentProcessor payPalProcessor = new PayPalPaymentAdapter(new PayPalPayment());
        payPalProcessor.processPayment(100.0);

        PaymentProcessor stripeProcessor = new StripePaymentAdapter(new StripePayment());
        stripeProcessor.processPayment(200.0);
    }
}

