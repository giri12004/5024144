package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.projection-ex8.DepartmentDTO;
import com.example.employeemanagementsystem.model.Department;

import org.hibernate.mapping.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public class DepartmentRepository extends JpaRepository<Department, Long>  {
    Department findByName(String name);
    

    //ex8
    @Query("SELECT new com.example.employeemanagementsystem.projection.DepartmentDTO(d.id, d.name) FROM Department d")
    List<DepartmentDTO> findAllDepartmentDTOs();

    @Query("SELECT d FROM Department d WHERE d.name = ?1")
    List<DepartmentSummary> findDepartmentSummariesByName(String name);
}
