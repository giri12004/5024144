package com.example.EmployeeManagementSystem.projection-ex8;

public interface departmentSummary {
    Long getId();
    String getName();
}
