package com.bookstore.BookStoreAPI.controller;

import java.net.URI;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

// import com.bookstore.BookStoreAPI.*;
import com.bookstore.BookStoreAPI.model.Book;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("/books")
public class BookController {
    
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = Arrays.asList(
            new Book(1L, "Spring Boot in Action", "Craig Walls", 45.99, "9781617292545"),
            new Book(2L, "Effective Java", "Joshua Bloch", 55.00, "9780134685991")
        );

        return ResponseEntity.ok()
            .header("X-Custom-Header", "CustomValue")
            .body(books);
    }


    @GetMapping("/{id}")
    public Book getBookById(@PathVariable Long id) {
        // Example: If the book is not found, throw an exception
        throw new ResourceNotfoundException("Book not found with id " + id);
    }

    @GetMapping("/search")
    public List<Book> searchBooks(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String author) {
        // This is just a placeholder. You would typically filter results from a database or in-memory list.
        List<Book> books = Arrays.asList(
            new Book(1L, "Spring Boot in Action", "Craig Walls", 45.99, "9781617292545"),
            new Book(2L, "Effective Java", "Joshua Bloch", 55.00, "9780134685991"),
            new Book(3L, "Java Concurrency in Practice", "Brian Goetz", 39.99, "9780321349606")
        );

        // Filtering based on the provided title and/or author
        return books.stream()
            .filter(book -> (title == null || book.getTitle().equalsIgnoreCase(title)) &&
                            (author == null || book.getAuthor().equalsIgnoreCase(author)))
            .collect(Collectors.toList());
    }


    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        // Assume the book is saved and has an ID of 1 (this is just for demonstration)
        book.setId(1L);

        // Build the URI for the created resource
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
            .path("/{id}")
            .buildAndExpand(book.getId())
            .toUri();

        return ResponseEntity.created(location)
            .header("X-Custom-Header", "CustomValue")
            .body(book);
    }


    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book book) {
        return book;
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteBook(@PathVariable Long id) {
        System.out.println("Deleted");
    }



}
